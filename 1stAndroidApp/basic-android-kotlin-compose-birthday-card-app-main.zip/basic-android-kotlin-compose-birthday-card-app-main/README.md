Happy Birthday app - Solution Code
==============================================

Solution code for the Android Basics with Compose: Add images to your Android app codelab.

Introduction
------------
In this codelab, you will learn how to add images to your app using an Image Composable.

Pre-requisites
--------------

You need to know:
- How to create and run a new app in Android Studio.

Getting Started
---------------

1. Download and run the app.